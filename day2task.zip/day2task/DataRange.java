import java.io.*;
import java.lang.*;

class DataRange{
	public static void main(String[] args){
		
		System.out.println("the min value of integer is "+Integer.MIN_VALUE);
		System.out.println("the min value of float is "+Float.MIN_VALUE);
		System.out.println("the min value of double is "+Double.MIN_VALUE);
		System.out.println("the min value of short is "+Short.MIN_VALUE);

		System.out.println("the max value of integer is "+Integer.MAX_VALUE);
		System.out.println("the max value of float is "+Float.MAX_VALUE);
		System.out.println("the max value of double is "+Double.MAX_VALUE);
		System.out.println("the max value of short is "+Short.MAX_VALUE);
	}
}

