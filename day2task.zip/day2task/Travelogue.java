class Travel{
	public int travelId;
	public String title;
	public String destination;
	public String[] keyWord;
	public String information;
    

    public static  
}

