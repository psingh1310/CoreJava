import java.io.Console;

class FirstExample {
	public static void main (String[] arg) {
		System.console().printf("Testing Java App");
	}
}